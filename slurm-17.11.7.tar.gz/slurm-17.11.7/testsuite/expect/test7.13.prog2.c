#include <stdio.h>

int main(int argc, char **argv)
{
	printf("fini 123\n");
	return 123;
}
