#include <stdio.h>

int main(int argc, char **argv)
{
	printf("fini 0\n");
	return 0;
}
