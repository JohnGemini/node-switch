
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include <slurm/slurm.h>
#include "testsuite/dejagnu.h"
int
main ( int argc, char* argv[] )
{
	exit (0);
}
